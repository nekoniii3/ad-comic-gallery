'use client'

import { useMemo, useState } from 'react'
import { MangaCard } from '@/components/manga-card'
import type { Manga } from '@/lib/manga-data'

type GenreFilterProps = {
  mangaList: Manga[]
}

export function GenreFilter({ mangaList }: GenreFilterProps) {
  const [activeGenre, setActiveGenre] = useState<string | null>(null)

  const allGenres = useMemo(() => {
    const genreSet = new Set<string>()
    mangaList.forEach((manga) => manga.genre.forEach((g) => genreSet.add(g)))
    return Array.from(genreSet).sort()
  }, [mangaList])

  const filtered = useMemo(
    () =>
      activeGenre
        ? mangaList.filter((manga) => manga.genre.includes(activeGenre))
        : mangaList,
    [mangaList, activeGenre],
  )

  return (
    <section className="px-4 pb-16">
      <div className="max-w-6xl mx-auto">
        {/* Header row */}
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-foreground font-bold text-lg flex items-center gap-2">
            <span className="w-1 h-5 bg-primary rounded-full inline-block" />
            全作品
          </h2>
          <span className="text-muted-foreground text-sm">
            {filtered.length} / {mangaList.length} 作品
          </span>
        </div>

        {/* Genre tags */}
        <div className="flex flex-wrap gap-2 mb-7" role="group" aria-label="ジャンルで絞り込む">
          <button
            onClick={() => setActiveGenre(null)}
            className={`text-xs px-3 py-1.5 rounded-full border transition-colors duration-150 font-medium ${
              activeGenre === null
                ? 'bg-primary text-primary-foreground border-primary'
                : 'bg-transparent text-muted-foreground border-border hover:border-primary hover:text-foreground'
            }`}
            aria-pressed={activeGenre === null}
          >
            すべて
          </button>
          {allGenres.map((genre) => (
            <button
              key={genre}
              onClick={() => setActiveGenre(activeGenre === genre ? null : genre)}
              className={`text-xs px-3 py-1.5 rounded-full border transition-colors duration-150 font-medium ${
                activeGenre === genre
                  ? 'bg-primary text-primary-foreground border-primary'
                  : 'bg-transparent text-muted-foreground border-border hover:border-primary hover:text-foreground'
              }`}
              aria-pressed={activeGenre === genre}
            >
              {genre}
            </button>
          ))}
        </div>

        {/* Grid */}
        {filtered.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {filtered.map((manga) => (
              <MangaCard key={manga.id} manga={manga} />
            ))}
          </div>
        ) : (
          <p className="text-center text-muted-foreground py-20 text-sm">
            該当する作品はありません
          </p>
        )}
      </div>
    </section>
  )
}
