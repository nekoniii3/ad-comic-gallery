import { notFound } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Calendar, BookOpen } from "lucide-react"
import { Header } from "@/components/header"
import { MangaGalleryViewer } from "@/components/manga-gallery-viewer"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { getMangaById, mangaList } from "@/lib/manga-data"

interface MangaPageProps {
  params: Promise<{ id: string }>
}

export async function generateStaticParams() {
  return mangaList.map((manga) => ({
    id: manga.id,
  }))
}

export async function generateMetadata({ params }: MangaPageProps) {
  const { id } = await params
  const manga = getMangaById(id)

  if (!manga) {
    return {
      title: "作品が見つかりません | Manga Gallery",
    }
  }

  return {
    title: `${manga.title} | Manga Gallery`,
    description: manga.description,
  }
}

export default async function MangaPage({ params }: MangaPageProps) {
  const { id } = await params
  const manga = getMangaById(id)

  if (!manga) {
    notFound()
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* 戻るボタン */}
        <div className="mb-6">
          <Button variant="ghost" asChild className="gap-2">
            <Link href="/">
              <ArrowLeft className="h-4 w-4" />
              ギャラリーに戻る
            </Link>
          </Button>
        </div>

        {/* 漫画情報ヘッダー */}
        <section className="mb-10 grid gap-8 lg:grid-cols-[280px,1fr]">
          {/* カバー画像 */}
          <div className="relative mx-auto aspect-[3/4] w-full max-w-[280px] overflow-hidden rounded-xl border border-border shadow-lg lg:mx-0">
            <Image
              src={manga.coverImage}
              alt={manga.title}
              fill
              className="object-cover"
              sizes="280px"
              priority
            />
          </div>

          {/* 漫画情報 */}
          <div className="flex flex-col justify-center">
            <Badge variant="secondary" className="mb-3 w-fit bg-secondary text-secondary-foreground">
              {manga.genre}
            </Badge>
            <h1 className="mb-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl lg:text-5xl text-balance">
              {manga.title}
            </h1>
            <p className="mb-6 text-lg text-muted-foreground text-pretty">
              {manga.description}
            </p>
            <div className="flex flex-wrap items-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                <span>{manga.pages.length}ページ</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>{new Date(manga.createdAt).toLocaleDateString("ja-JP")}</span>
              </div>
            </div>
          </div>
        </section>

        {/* 区切り線 */}
        <div className="mb-10 border-t border-border" />

        {/* ギャラリービューワー */}
        <MangaGalleryViewer pages={manga.pages} title={manga.title} />
      </main>

      {/* フッター */}
      <footer className="mt-16 border-t border-border bg-card">
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-muted-foreground">
            &copy; 2024 Manga Gallery. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}
