import { Header } from "@/components/header"
import { MangaGrid } from "@/components/manga-grid"

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* ヒーローセクション */}
        <section className="mb-12 text-center">
          <h1 className="mb-4 text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl">
            <span className="text-balance">Manga Gallery</span>
          </h1>
          <p className="mx-auto max-w-2xl text-lg text-muted-foreground text-pretty">
            作成した漫画作品をギャラリー形式でお楽しみください。
            お気に入りの作品を選んで、ページをめくるように閲覧できます。
          </p>
        </section>

        {/* 漫画一覧 */}
        <MangaGrid />
      </main>

      {/* フッター */}
      <footer className="border-t border-border bg-card">
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-muted-foreground">
            &copy; 2024 Manga Gallery. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}
