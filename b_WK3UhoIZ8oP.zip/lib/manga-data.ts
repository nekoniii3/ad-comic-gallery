export interface MangaPage {
  id: number
  imageUrl: string
  alt: string
}

export interface Manga {
  id: string
  title: string
  description: string
  coverImage: string
  genre: string
  pages: MangaPage[]
  createdAt: string
}

// サンプルデータ - 実際のプロジェクトではデータベースから取得
export const mangaList: Manga[] = [
  {
    id: "adventure-quest",
    title: "冒険の始まり",
    description: "若き勇者が世界を救う壮大な冒険ファンタジー",
    coverImage: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=400&h=600&fit=crop",
    genre: "ファンタジー",
    pages: [
      { id: 1, imageUrl: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=800&h=1200&fit=crop", alt: "第1話 旅立ち" },
      { id: 2, imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&h=1200&fit=crop", alt: "第2話 出会い" },
      { id: 3, imageUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=1200&fit=crop", alt: "第3話 試練" },
      { id: 4, imageUrl: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&h=1200&fit=crop", alt: "第4話 覚醒" },
    ],
    createdAt: "2024-01-15",
  },
  {
    id: "cyber-city",
    title: "サイバーシティ2099",
    description: "近未来都市を舞台にしたサイバーパンクアクション",
    coverImage: "https://images.unsplash.com/photo-1480796927426-f609979314bd?w=400&h=600&fit=crop",
    genre: "SF",
    pages: [
      { id: 1, imageUrl: "https://images.unsplash.com/photo-1480796927426-f609979314bd?w=800&h=1200&fit=crop", alt: "Episode 1: Neon Lights" },
      { id: 2, imageUrl: "https://images.unsplash.com/photo-1545486332-9e0999c535b2?w=800&h=1200&fit=crop", alt: "Episode 2: Underground" },
      { id: 3, imageUrl: "https://images.unsplash.com/photo-1514565131-fce0801e5785?w=800&h=1200&fit=crop", alt: "Episode 3: Rebellion" },
    ],
    createdAt: "2024-02-20",
  },
  {
    id: "daily-life",
    title: "ほのぼの日常",
    description: "心温まる学校生活を描いた日常コメディ",
    coverImage: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=400&h=600&fit=crop",
    genre: "日常",
    pages: [
      { id: 1, imageUrl: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=800&h=1200&fit=crop", alt: "第1話 新学期" },
      { id: 2, imageUrl: "https://images.unsplash.com/photo-1509062522246-3755977927d7?w=800&h=1200&fit=crop", alt: "第2話 新しい友達" },
      { id: 3, imageUrl: "https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?w=800&h=1200&fit=crop", alt: "第3話 放課後" },
      { id: 4, imageUrl: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=800&h=1200&fit=crop", alt: "第4話 図書館" },
      { id: 5, imageUrl: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=800&h=1200&fit=crop", alt: "第5話 試験前夜" },
    ],
    createdAt: "2024-03-10",
  },
  {
    id: "midnight-detective",
    title: "真夜中の探偵",
    description: "闇夜に潜む謎を解き明かすミステリー",
    coverImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=600&fit=crop",
    genre: "ミステリー",
    pages: [
      { id: 1, imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=1200&fit=crop", alt: "Case 1: 消えた手紙" },
      { id: 2, imageUrl: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=800&h=1200&fit=crop", alt: "Case 2: デジタルの痕跡" },
      { id: 3, imageUrl: "https://images.unsplash.com/photo-1512428559087-560fa5ceab42?w=800&h=1200&fit=crop", alt: "Case 3: 真実への道" },
    ],
    createdAt: "2024-03-25",
  },
  {
    id: "dragon-spirit",
    title: "龍の魂",
    description: "古代から蘇りし龍と人間の絆を描く伝説",
    coverImage: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&h=600&fit=crop",
    genre: "ファンタジー",
    pages: [
      { id: 1, imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&h=1200&fit=crop", alt: "第1章 目覚め" },
      { id: 2, imageUrl: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800&h=1200&fit=crop", alt: "第2章 絆" },
      { id: 3, imageUrl: "https://images.unsplash.com/photo-1433086966358-54859d0ed716?w=800&h=1200&fit=crop", alt: "第3章 滝の試練" },
      { id: 4, imageUrl: "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&h=1200&fit=crop", alt: "第4章 自然の力" },
    ],
    createdAt: "2024-04-05",
  },
  {
    id: "ocean-voyage",
    title: "蒼海の航路",
    description: "大海原を舞台にした海洋冒険ロマン",
    coverImage: "https://images.unsplash.com/photo-1505142468610-359e7d316be0?w=400&h=600&fit=crop",
    genre: "冒険",
    pages: [
      { id: 1, imageUrl: "https://images.unsplash.com/photo-1505142468610-359e7d316be0?w=800&h=1200&fit=crop", alt: "航海日誌1: 出航" },
      { id: 2, imageUrl: "https://images.unsplash.com/photo-1439066615861-d1af74d74000?w=800&h=1200&fit=crop", alt: "航海日誌2: 嵐の前" },
      { id: 3, imageUrl: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=1200&fit=crop", alt: "航海日誌3: 新天地" },
    ],
    createdAt: "2024-04-18",
  },
]

export function getMangaById(id: string): Manga | undefined {
  return mangaList.find((manga) => manga.id === id)
}

export function getAllGenres(): string[] {
  return [...new Set(mangaList.map((manga) => manga.genre))]
}
