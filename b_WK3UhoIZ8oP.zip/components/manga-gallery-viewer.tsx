"use client"

import { useState, useCallback, useEffect } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { ChevronLeft, ChevronRight, X, ZoomIn, Grid3X3 } from "lucide-react"
import type { MangaPage } from "@/lib/manga-data"

interface MangaGalleryViewerProps {
  pages: MangaPage[]
  title: string
}

export function MangaGalleryViewer({ pages, title }: MangaGalleryViewerProps) {
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null)
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")

  const handlePrevious = useCallback(() => {
    if (selectedIndex !== null && selectedIndex > 0) {
      setSelectedIndex(selectedIndex - 1)
    }
  }, [selectedIndex])

  const handleNext = useCallback(() => {
    if (selectedIndex !== null && selectedIndex < pages.length - 1) {
      setSelectedIndex(selectedIndex + 1)
    }
  }, [selectedIndex, pages.length])

  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (selectedIndex === null) return
      if (e.key === "ArrowLeft") handlePrevious()
      if (e.key === "ArrowRight") handleNext()
      if (e.key === "Escape") setSelectedIndex(null)
    },
    [selectedIndex, handlePrevious, handleNext]
  )

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [handleKeyDown])

  return (
    <div>
      {/* ビューモード切り替え */}
      <div className="mb-6 flex items-center justify-between">
        <h2 className="text-lg font-semibold text-foreground">
          全{pages.length}ページ
        </h2>
        <div className="flex items-center gap-2">
          <Button
            variant={viewMode === "grid" ? "default" : "secondary"}
            size="sm"
            onClick={() => setViewMode("grid")}
          >
            <Grid3X3 className="h-4 w-4" />
          </Button>
          <Button
            variant={viewMode === "list" ? "default" : "secondary"}
            size="sm"
            onClick={() => setViewMode("list")}
          >
            <ZoomIn className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* グリッド表示 */}
      {viewMode === "grid" && (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {pages.map((page, index) => (
            <button
              key={page.id}
              onClick={() => setSelectedIndex(index)}
              className="group relative aspect-[3/4] overflow-hidden rounded-lg border border-border bg-card transition-all hover:border-accent/50 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-accent"
            >
              <Image
                src={page.imageUrl}
                alt={page.alt}
                fill
                className="object-cover transition-transform duration-300 group-hover:scale-105"
                sizes="(max-width: 640px) 50vw, (max-width: 768px) 33vw, (max-width: 1024px) 25vw, 20vw"
              />
              <div className="absolute inset-0 flex items-center justify-center bg-background/60 opacity-0 transition-opacity group-hover:opacity-100">
                <ZoomIn className="h-8 w-8 text-foreground" />
              </div>
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background/90 to-transparent p-2">
                <span className="text-xs font-medium text-foreground">{index + 1}</span>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* リスト表示（縦スクロール） */}
      {viewMode === "list" && (
        <div className="space-y-4">
          {pages.map((page, index) => (
            <div
              key={page.id}
              className="overflow-hidden rounded-lg border border-border bg-card"
            >
              <div className="relative aspect-[3/4] w-full max-w-2xl mx-auto">
                <Image
                  src={page.imageUrl}
                  alt={page.alt}
                  fill
                  className="object-contain"
                  sizes="(max-width: 768px) 100vw, 672px"
                  priority={index < 2}
                />
              </div>
              <div className="border-t border-border bg-secondary/30 p-3 text-center">
                <span className="text-sm text-muted-foreground">
                  {index + 1} / {pages.length} - {page.alt}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* フルスクリーンビューワー */}
      <Dialog open={selectedIndex !== null} onOpenChange={() => setSelectedIndex(null)}>
        <DialogContent className="max-w-[95vw] h-[95vh] p-0 bg-background border-border">
          <div className="relative flex h-full items-center justify-center">
            {/* 閉じるボタン */}
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-4 top-4 z-50 rounded-full bg-background/80 hover:bg-background"
              onClick={() => setSelectedIndex(null)}
            >
              <X className="h-5 w-5" />
              <span className="sr-only">閉じる</span>
            </Button>

            {/* 前へボタン */}
            {selectedIndex !== null && selectedIndex > 0 && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute left-4 top-1/2 z-50 -translate-y-1/2 rounded-full bg-background/80 hover:bg-background"
                onClick={handlePrevious}
              >
                <ChevronLeft className="h-6 w-6" />
                <span className="sr-only">前のページ</span>
              </Button>
            )}

            {/* 画像 */}
            {selectedIndex !== null && (
              <div className="relative h-full w-full p-8">
                <Image
                  src={pages[selectedIndex].imageUrl}
                  alt={pages[selectedIndex].alt}
                  fill
                  className="object-contain"
                  sizes="95vw"
                  priority
                />
              </div>
            )}

            {/* 次へボタン */}
            {selectedIndex !== null && selectedIndex < pages.length - 1 && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-4 top-1/2 z-50 -translate-y-1/2 rounded-full bg-background/80 hover:bg-background"
                onClick={handleNext}
              >
                <ChevronRight className="h-6 w-6" />
                <span className="sr-only">次のページ</span>
              </Button>
            )}

            {/* ページ情報 */}
            {selectedIndex !== null && (
              <div className="absolute bottom-4 left-1/2 z-50 -translate-x-1/2 rounded-full bg-background/80 px-4 py-2">
                <span className="text-sm font-medium text-foreground">
                  {selectedIndex + 1} / {pages.length}
                </span>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
