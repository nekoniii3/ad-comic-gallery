import Link from "next/link"
import { BookOpen } from "lucide-react"

export function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-3 transition-opacity hover:opacity-80">
          <BookOpen className="h-7 w-7 text-accent" />
          <span className="text-xl font-bold tracking-tight text-foreground">
            Manga Gallery
          </span>
        </Link>
        <nav className="flex items-center gap-6">
          <Link 
            href="/" 
            className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            ギャラリー
          </Link>
        </nav>
      </div>
    </header>
  )
}
