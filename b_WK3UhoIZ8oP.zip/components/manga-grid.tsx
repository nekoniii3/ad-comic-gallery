"use client"

import { useState, useCallback, useEffect } from "react"
import Image from "next/image"
import { mangaList, getAllGenres, type Manga } from "@/lib/manga-data"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { ChevronLeft, ChevronRight, X } from "lucide-react"

export function MangaGrid() {
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null)
  const [selectedManga, setSelectedManga] = useState<Manga | null>(null)
  const [currentPageIndex, setCurrentPageIndex] = useState(0)
  const genres = getAllGenres()

  const filteredManga = selectedGenre
    ? mangaList.filter((manga) => manga.genre === selectedGenre)
    : mangaList

  const handleOpenViewer = (manga: Manga) => {
    setSelectedManga(manga)
    setCurrentPageIndex(0)
  }

  const handleCloseViewer = () => {
    setSelectedManga(null)
    setCurrentPageIndex(0)
  }

  const handlePrevious = useCallback(() => {
    if (currentPageIndex > 0) {
      setCurrentPageIndex(currentPageIndex - 1)
    }
  }, [currentPageIndex])

  const handleNext = useCallback(() => {
    if (selectedManga && currentPageIndex < selectedManga.pages.length - 1) {
      setCurrentPageIndex(currentPageIndex + 1)
    }
  }, [currentPageIndex, selectedManga])

  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (!selectedManga) return
      if (e.key === "ArrowLeft") handlePrevious()
      if (e.key === "ArrowRight") handleNext()
      if (e.key === "Escape") handleCloseViewer()
    },
    [selectedManga, handlePrevious, handleNext]
  )

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [handleKeyDown])

  return (
    <section className="py-8">
      {/* ジャンルフィルター */}
      <div className="mb-8 flex flex-wrap items-center gap-2">
        <Button
          variant={selectedGenre === null ? "default" : "secondary"}
          size="sm"
          onClick={() => setSelectedGenre(null)}
          className="rounded-full"
        >
          すべて
        </Button>
        {genres.map((genre) => (
          <Button
            key={genre}
            variant={selectedGenre === genre ? "default" : "secondary"}
            size="sm"
            onClick={() => setSelectedGenre(genre)}
            className="rounded-full"
          >
            {genre}
          </Button>
        ))}
      </div>

      {/* 漫画グリッド */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {filteredManga.map((manga) => (
          <button
            key={manga.id}
            onClick={() => handleOpenViewer(manga)}
            className="group block text-left w-full"
          >
            <article className="overflow-hidden rounded-lg border border-border bg-card transition-all duration-300 hover:border-accent/50 hover:shadow-lg hover:shadow-accent/5">
              <div className="relative aspect-[3/4] overflow-hidden">
                <Image
                  src={manga.coverImage}
                  alt={manga.title}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
                <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-4 opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
                  <p className="text-sm text-foreground/90 line-clamp-2">{manga.description}</p>
                </div>
              </div>
              <div className="p-4">
                <div className="mb-2 flex items-center justify-between">
                  <Badge variant="secondary" className="bg-secondary text-secondary-foreground text-xs">
                    {manga.genre}
                  </Badge>
                  <span className="text-xs text-muted-foreground">{manga.pages.length}ページ</span>
                </div>
                <h3 className="font-bold text-foreground text-lg leading-tight group-hover:text-accent transition-colors">
                  {manga.title}
                </h3>
              </div>
            </article>
          </button>
        ))}
      </div>

      {filteredManga.length === 0 && (
        <div className="py-16 text-center">
          <p className="text-muted-foreground">該当する漫画がありません</p>
        </div>
      )}

      {/* フルスクリーンビューワー */}
      <Dialog open={selectedManga !== null} onOpenChange={handleCloseViewer}>
        <DialogContent className="max-w-[95vw] h-[95vh] p-0 bg-background border-border">
          <div className="relative flex h-full items-center justify-center">
            {/* 作品タイトル */}
            {selectedManga && (
              <div className="absolute top-4 left-4 z-50 rounded-full bg-background/80 px-4 py-2">
                <span className="text-sm font-medium text-foreground">
                  {selectedManga.title}
                </span>
              </div>
            )}

            {/* 閉じるボタン */}
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-4 top-4 z-50 rounded-full bg-background/80 hover:bg-background"
              onClick={handleCloseViewer}
            >
              <X className="h-5 w-5" />
              <span className="sr-only">閉じる</span>
            </Button>

            {/* 前へボタン */}
            {currentPageIndex > 0 && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute left-4 top-1/2 z-50 -translate-y-1/2 rounded-full bg-background/80 hover:bg-background"
                onClick={handlePrevious}
              >
                <ChevronLeft className="h-6 w-6" />
                <span className="sr-only">前のページ</span>
              </Button>
            )}

            {/* 画像 */}
            {selectedManga && (
              <div className="relative h-full w-full p-8">
                <Image
                  src={selectedManga.pages[currentPageIndex].imageUrl}
                  alt={selectedManga.pages[currentPageIndex].alt}
                  fill
                  className="object-contain"
                  sizes="95vw"
                  priority
                />
              </div>
            )}

            {/* 次へボタン */}
            {selectedManga && currentPageIndex < selectedManga.pages.length - 1 && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-4 top-1/2 z-50 -translate-y-1/2 rounded-full bg-background/80 hover:bg-background"
                onClick={handleNext}
              >
                <ChevronRight className="h-6 w-6" />
                <span className="sr-only">次のページ</span>
              </Button>
            )}

            {/* ページ情報 */}
            {selectedManga && (
              <div className="absolute bottom-4 left-1/2 z-50 -translate-x-1/2 rounded-full bg-background/80 px-4 py-2">
                <span className="text-sm font-medium text-foreground">
                  {currentPageIndex + 1} / {selectedManga.pages.length}
                </span>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </section>
  )
}
